# Create your views here.
categories = Category.objects.filter()
